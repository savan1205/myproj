from odoo import fields, models,api

class HospitalDoctorName(models.Model):
    _name = "doctor.name"
    _description="doctor name"

    name = fields.Char(string="Name")
    # speciality_id = fields.Many2one(comodel_name="",string="speciality")
    degrees_id = fields.Many2many(comodel_name="hospital.degrees",string="Degree")
    belongsTo = fields.Selection([('Yes','yes'),('No','no')],string="Belongs to this Hospital") 