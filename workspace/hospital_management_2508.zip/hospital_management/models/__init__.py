from . import patient
from . import appointments
from . import department
from . import doctor
from . import doctorName
from . import degrees
from . import reference

