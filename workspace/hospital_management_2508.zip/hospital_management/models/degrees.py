from odoo import fields, models,api

class HospitalDegrees(models.Model):
    _name = "hospital.degrees"
    _description = "hospital degrees"

    degrees = fields.Char(string="degrees")
    