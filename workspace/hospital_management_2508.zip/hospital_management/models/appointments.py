from odoo import fields, models,api
from datetime import date, datetime


class HospitalAppointments(models.Model):
    _name = "hospital.appointments"
    _description = "Hospital Appointments"

    name_id=fields.Many2one(comodel_name="hospital.patient",string="Patient Name:")
    date=fields.Datetime(string="Date")
    doctor_id=fields.Many2one(comodel_name="doctor.name",string="With Doctor:")




    
    